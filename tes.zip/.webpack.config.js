module.exports = config => {
    config.target = 'electron-renderer'
    return config;
} 