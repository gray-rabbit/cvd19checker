import React from 'react';
import TestHook from './utils/testHook';

const MainPage = () => {
    // const test = TestHook(123);
    return (
        <div>
            <p>메인페이지</p>
        </div>
    )
}


export default MainPage;