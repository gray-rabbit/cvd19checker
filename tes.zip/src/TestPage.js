import React from 'react';
import Cvd19Hook from './utils/Cvd19Hook';

const TestPage = () => {
    const [list, setData] = Cvd19Hook();
    console.log('ㅅㄷㄴㅅ');
    return (
        <div>
            <p>테스트 페이지</p>
            <button onClick={
                ()=>{
                    setData('박성준','g8naew')
                }
            }>로드</button>
        </div>
    )
}

export default TestPage;