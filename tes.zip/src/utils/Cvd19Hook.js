import { useState, useEffect, useCallback } from 'react';
const fetch = require('electron').remote.require('electron-fetch').default;


function formToString(obj) {
    let str = [];
    Object.keys(obj).map(key => {
        str.push(`${key}=${obj[key]}`)
        return key;
    })
    return str.join('&');
}


const data = {
    qstnCrtfcNoEncpt: '',
    pName: encodeURIComponent(''),
    qstnCrtfcNo: ''
}
const temp = [10, 20]
const Cvd19Hook = () => {
    const [time, setTime] = useState(0);
    const [list, setList] = useState(null);

    const setData = useCallback((name, code) => {
        if (name === '' || code === '') return;
        const str = formToString({ ...data, qstnCrtfcNo: code, pName: encodeURI(name) })
        console.log(str);
        let cookie;
        fetch('https://eduro.cbe.go.kr/stv_cvd_co00_011.do', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            },
            body: str
        }).then(async r => {
            console.log(r.status);
            const raw = r.headers.raw()['set-cookie']
            cookie = raw.map(el => {
                const temp = el.split(';');
                return temp[0];
            }).join(';');

            return r.json();

        }).then(r => {
            const link = r['resultSVO']['data']['qstnCrtfcNoEncpt'].substr(1);
            return fetch(`https://eduro.cbe.go.kr/stv_cvd_co03_000.do?k=${link}`, {
                method: 'GET',
                headers: {
                    cookie
                }
            })
        }).then(r=>{
            return r.text();
        }).then(r=>{
            console.log(r);
        });
    });

    return [list, setData]
    // return [list, setData]
}

export default Cvd19Hook;